package com.cg.Spring1;

public class CurrencyConverterImpl implements CurrencyConverter {
	private ExchangeService exchangeService;
//setters and getters
	public ExchangeService getExchangeService() {
		System.out.println("getExchangeService()");
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		System.out.println("setExchangeService()");
		this.exchangeService = exchangeService;
	}
//default constructor
	public CurrencyConverterImpl() {
		System.out.println("CurrencyConverterImpl()");
	}


	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRupees()");
		return dollars * exchangeService.getExchangeRate();
	}

}
