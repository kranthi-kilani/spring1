package com.cg.Spring1;

public interface CurrencyConverter {
	
	public double dollarsToRupees(double dollars);

}
