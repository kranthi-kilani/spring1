package com.cg.Spring1;

public interface ExchangeService {

	
	public double getExchangeRate();
}
