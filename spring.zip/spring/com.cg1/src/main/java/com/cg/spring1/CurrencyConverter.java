package com.cg.spring1;

public interface CurrencyConverter {
	
	public double dollarsToRupees(double dollars);

}
