package com.cg.spring1;

public interface ExchangeService {

	
	public double getExchangeRate();
}
